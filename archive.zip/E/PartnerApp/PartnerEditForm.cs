using PartnerApp.DataAccess;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Windows.Forms;
using PartnerApp.DataAccess;
namespace PartnerApp
{
    public partial class PartnerEditForm : Form
    {
        private int? partnerId;
        private ComboBox cmbType;
        private TextBox txtName, txtDirector, txtEmail, txtPhone, txtAddress, txtINN, txtRating;
        private Button btnSave;

        public PartnerEditForm(int? id = null)
        {
            partnerId = id;
            InitializeComponent();
            LoadPartnerTypes();
            if (id.HasValue) LoadPartnerData(id.Value);
        }

        private void InitializeComponent()
        {
            cmbType = new ComboBox();
            txtName = new TextBox();
            txtDirector = new TextBox();
            txtEmail = new TextBox();
            txtPhone = new TextBox();
            txtAddress = new TextBox();
            txtINN = new TextBox();
            txtRating = new TextBox();
            btnSave = new Button();
            SuspendLayout();

            cmbType.Location = new Point(120, 20); cmbType.Size = new Size(200, 23);
            txtName.Location = new Point(120, 50); txtName.Size = new Size(200, 23);
            txtDirector.Location = new Point(120, 80); txtDirector.Size = new Size(200, 23);
            txtEmail.Location = new Point(120, 110); txtEmail.Size = new Size(200, 23);
            txtPhone.Location = new Point(120, 140); txtPhone.Size = new Size(200, 23);
            txtAddress.Location = new Point(120, 170); txtAddress.Size = new Size(300, 23);
            txtINN.Location = new Point(120, 200); txtINN.Size = new Size(150, 23);
            txtRating.Location = new Point(120, 230); txtRating.Size = new Size(100, 23);
            btnSave.Text = "Сохранить"; btnSave.Location = new Point(120, 270);
            btnSave.Click += BtnSave_Click;

            Controls.AddRange(new Control[] { cmbType, txtName, txtDirector, txtEmail, txtPhone, txtAddress, txtINN, txtRating, btnSave });
            Text = partnerId.HasValue ? "Редактирование партнёра" : "Добавление партнёра";
            ClientSize = new Size(450, 320);
            ResumeLayout(false);
        }

        private void LoadPartnerTypes()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT Id, Name FROM PartnerTypes");
            cmbType.DataSource = dt;
            cmbType.DisplayMember = "Name";
            cmbType.ValueMember = "Id";
        }

        private void LoadPartnerData(int id)
        {
            string query = "SELECT * FROM Partners WHERE Id = @Id";
            var param = new SqlParameter("@Id", id);
            DataTable dt = DatabaseHelper.ExecuteQuery(query, new[] { param });
            if (dt.Rows.Count > 0)
            {
                cmbType.SelectedValue = dt.Rows[0]["PartnerTypeId"];
                txtName.Text = dt.Rows[0]["Name"].ToString();
                txtDirector.Text = dt.Rows[0]["DirectorName"].ToString();
                txtEmail.Text = dt.Rows[0]["Email"].ToString();
                txtPhone.Text = dt.Rows[0]["Phone"].ToString();
                txtAddress.Text = dt.Rows[0]["LegalAddress"].ToString();
                txtINN.Text = dt.Rows[0]["INN"].ToString();
                txtRating.Text = dt.Rows[0]["Rating"].ToString();
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (!int.TryParse(txtRating.Text, out int rating) || rating < 0)
            {
                MessageBox.Show("Рейтинг – целое неотрицательное число", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query;
            SqlParameter[] parameters;
            if (partnerId.HasValue)
            {
                query = @"UPDATE Partners SET PartnerTypeId=@TypeId, Name=@Name, DirectorName=@Director,
                          Email=@Email, Phone=@Phone, LegalAddress=@Address, INN=@INN, Rating=@Rating
                          WHERE Id=@Id";
                parameters = new SqlParameter[]
                {
                    new SqlParameter("@Id", partnerId.Value),
                    new SqlParameter("@TypeId", cmbType.SelectedValue),
                    new SqlParameter("@Name", txtName.Text),
                    new SqlParameter("@Director", txtDirector.Text),
                    new SqlParameter("@Email", txtEmail.Text),
                    new SqlParameter("@Phone", txtPhone.Text),
                    new SqlParameter("@Address", txtAddress.Text),
                    new SqlParameter("@INN", txtINN.Text),
                    new SqlParameter("@Rating", rating)
                };
            }
            else
            {
                query = @"INSERT INTO Partners (PartnerTypeId, Name, DirectorName, Email, Phone, LegalAddress, INN, Rating)
                          VALUES (@TypeId, @Name, @Director, @Email, @Phone, @Address, @INN, @Rating)";
                parameters = new SqlParameter[]
                {
                    new SqlParameter("@TypeId", cmbType.SelectedValue),
                    new SqlParameter("@Name", txtName.Text),
                    new SqlParameter("@Director", txtDirector.Text),
                    new SqlParameter("@Email", txtEmail.Text),
                    new SqlParameter("@Phone", txtPhone.Text),
                    new SqlParameter("@Address", txtAddress.Text),
                    new SqlParameter("@INN", txtINN.Text),
                    new SqlParameter("@Rating", rating)
                };
            }
            DatabaseHelper.ExecuteNonQuery(query, parameters);
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}