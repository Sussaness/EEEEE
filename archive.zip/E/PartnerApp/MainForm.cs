using System;
using PartnerApp.DataAccess;
using PartnerApp.Utils;
using System.Data;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Windows.Forms;
using PartnerApp.DataAccess;
using PartnerApp.Utils;

namespace PartnerApp
{
    public partial class MainForm : Form
    {
        private DataGridView dgvPartners;
        private Button btnAdd, btnEdit, btnHistory;
        private DataTable partnersTable;

        public MainForm()
        {
            InitializeComponent();
            LoadPartners();
        }

        private void InitializeComponent()
        {
            dgvPartners = new DataGridView();
            btnAdd = new Button();
            btnEdit = new Button();
            btnHistory = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPartners).BeginInit();
            SuspendLayout();

            dgvPartners.Location = new Point(12, 12);
            dgvPartners.Size = new Size(760, 400);
            dgvPartners.ReadOnly = true;
            dgvPartners.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            btnAdd.Text = "Добавить";
            btnAdd.Location = new Point(12, 420);
            btnAdd.Click += BtnAdd_Click;

            btnEdit.Text = "Редактировать";
            btnEdit.Location = new Point(100, 420);
            btnEdit.Click += BtnEdit_Click;

            btnHistory.Text = "История продаж";
            btnHistory.Location = new Point(220, 420);
            btnHistory.Click += BtnHistory_Click;

            Controls.Add(dgvPartners);
            Controls.Add(btnAdd);
            Controls.Add(btnEdit);
            Controls.Add(btnHistory);
            ClientSize = new Size(784, 461);
            Text = "Учёт партнёров";
            ((System.ComponentModel.ISupportInitialize)dgvPartners).EndInit();
            ResumeLayout(false);
        }

        private void LoadPartners()
        {
            string query = @"
                SELECT p.Id, pt.Name AS PartnerType, p.Name, p.DirectorName, p.Phone, p.Rating
                FROM Partners p
                JOIN PartnerTypes pt ON p.PartnerTypeId = pt.Id";
            partnersTable = DatabaseHelper.ExecuteQuery(query);
            dgvPartners.DataSource = partnersTable;
            if (!dgvPartners.Columns.Contains("Discount"))
            {
                DataGridViewTextBoxColumn discCol = new DataGridViewTextBoxColumn();
                discCol.Name = "Discount";
                discCol.HeaderText = "Скидка";
                discCol.ReadOnly = true;
                dgvPartners.Columns.Add(discCol);
            }
            for (int i = 0; i < dgvPartners.Rows.Count; i++)
            {
                int id = Convert.ToInt32(dgvPartners.Rows[i].Cells["Id"].Value);
                decimal discount = DiscountCalculator.GetDiscountForPartner(id);
                dgvPartners.Rows[i].Cells["Discount"].Value = $"{discount:P0}";
            }
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            using (var editForm = new PartnerEditForm())
            {
                if (editForm.ShowDialog() == DialogResult.OK)
                    LoadPartners();
            }
        }

        private void BtnEdit_Click(object? sender, EventArgs e)
        {
            if (dgvPartners.CurrentRow == null) return;
            int id = Convert.ToInt32(dgvPartners.CurrentRow.Cells["Id"].Value);
            using (var editForm = new PartnerEditForm(id))
            {
                if (editForm.ShowDialog() == DialogResult.OK)
                    LoadPartners();
            }
        }

        private void BtnHistory_Click(object? sender, EventArgs e)
        {
            if (dgvPartners.CurrentRow == null) return;
            int id = Convert.ToInt32(dgvPartners.CurrentRow.Cells["Id"].Value);
            string name = dgvPartners.CurrentRow.Cells["Name"].Value.ToString() ?? "";
            using (var historyForm = new SalesHistoryForm(id, name))
                historyForm.ShowDialog();
        }
    }
}