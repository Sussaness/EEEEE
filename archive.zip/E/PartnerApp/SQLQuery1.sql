﻿-- Создаём логин для вашей учётной записи Microsoft
CREATE LOGIN [MicrosoftAccount\zinovkinaksenia6@gmail.com] FROM WINDOWS;

-- Даём этому логину права администратора сервера (sysadmin)
ALTER SERVER ROLE [sysadmin] ADD MEMBER [MicrosoftAccount\zinovkinaksenia6@gmail.com];
GO