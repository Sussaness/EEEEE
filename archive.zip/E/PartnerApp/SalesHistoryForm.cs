using PartnerApp.DataAccess;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System;
using System.Drawing;
using System.Windows.Forms;
using PartnerApp.DataAccess;

namespace PartnerApp
{
    public partial class SalesHistoryForm : Form
    {
        private DataGridView dgvHistory;

        public SalesHistoryForm(int partnerId, string partnerName)
        {
            InitializeComponent();
            Text = $"История продаж: {partnerName}";
            LoadHistory(partnerId);
        }

        private void InitializeComponent()
        {
            dgvHistory = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvHistory).BeginInit();
            SuspendLayout();
            dgvHistory.Dock = DockStyle.Fill;
            dgvHistory.ReadOnly = true;
            dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Controls.Add(dgvHistory);
            ClientSize = new Size(600, 400);
            ((System.ComponentModel.ISupportInitialize)dgvHistory).EndInit();
            ResumeLayout(false);
        }

        private void LoadHistory(int partnerId)
        {
            string query = @"
                SELECT p.Name AS Product, sh.Quantity, sh.SaleDate
                FROM SalesHistory sh
                JOIN Products p ON sh.ProductId = p.Id
                WHERE sh.PartnerId = @PartnerId
                ORDER BY sh.SaleDate DESC";
            var param = new SqlParameter("@PartnerId", partnerId);
            DataTable dt = DatabaseHelper.ExecuteQuery(query, new[] { param });
            dgvHistory.DataSource = dt;
        }
    }
}