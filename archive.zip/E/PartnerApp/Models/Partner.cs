namespace PartnerApp.Models
{
    public class Partner
    {
        public int Id { get; set; }
        public int PartnerTypeId { get; set; }
        public string Name { get; set; } = "";
        public string? DirectorName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? LegalAddress { get; set; }
        public string? INN { get; set; }
        public int Rating { get; set; }
    }
}