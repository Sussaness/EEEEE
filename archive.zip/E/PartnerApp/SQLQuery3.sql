﻿USE ExamDB;
CREATE USER [MicrosoftAccount\zinovkinaksenia6@gmail.com] FOR LOGIN [MicrosoftAccount\zinovkinaksenia6@gmail.com];
ALTER ROLE [db_owner] ADD MEMBER [MicrosoftAccount\zinovkinaksenia6@gmail.com];