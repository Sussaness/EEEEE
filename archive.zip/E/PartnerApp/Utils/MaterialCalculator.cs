using System;
using System.Data;
using PartnerApp.DataAccess;
using PartnerApp.DataAccess;
using System.Data.SqlClient;

namespace PartnerApp.Utils
{
    public static class MaterialCalculator
    {
        public static int CalculateMaterial(int productTypeId, int materialTypeId, int productQuantity, double param1, double param2)
        {
            // Получаем коэффициент типа продукции
            DataTable dtProd = DatabaseHelper.ExecuteQuery("SELECT Coefficient FROM ProductTypes WHERE Id = @Id",
                new[] { new SqlParameter("@Id", productTypeId) });
            if (dtProd.Rows.Count == 0) return -1;
            double prodCoeff = Convert.ToDouble(dtProd.Rows[0]["Coefficient"]);

            // Получаем процент брака материала
            DataTable dtMat = DatabaseHelper.ExecuteQuery("SELECT DefectPercent FROM MaterialTypes WHERE Id = @Id",
                new[] { new SqlParameter("@Id", materialTypeId) });
            if (dtMat.Rows.Count == 0) return -1;
            double defectPercent = Convert.ToDouble(dtMat.Rows[0]["DefectPercent"]);

            double materialPerUnit = param1 * param2 * prodCoeff;
            double totalMaterial = materialPerUnit * productQuantity;
            totalMaterial *= (1 + defectPercent);
            return (int)Math.Ceiling(totalMaterial);
        }
    }
}