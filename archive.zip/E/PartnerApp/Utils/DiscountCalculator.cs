using System;
using PartnerApp.DataAccess;
using PartnerApp.DataAccess;
using System.Data.SqlClient;

namespace PartnerApp.Utils
{
    public static class DiscountCalculator
    {
        public static decimal GetDiscountForPartner(int partnerId)
        {
            string query = "SELECT SUM(Quantity) FROM SalesHistory WHERE PartnerId = @PartnerId";
            var param = new SqlParameter("@PartnerId", partnerId);
            object? result = DatabaseHelper.ExecuteScalar(query, new[] { param });
            int totalQuantity = (result == DBNull.Value) ? 0 : Convert.ToInt32(result);

            if (totalQuantity >= 10000) return 0.12m;
            if (totalQuantity >= 5000) return 0.08m;
            if (totalQuantity >= 1000) return 0.05m;
            return 0m;
        }
    }
}