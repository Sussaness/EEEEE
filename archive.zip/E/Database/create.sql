-- Скрипт создания базы данных для демоэкзамена
CREATE DATABASE ExamDB;
GO
USE ExamDB;
GO

-- Типы партнёров
CREATE TABLE PartnerTypes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL UNIQUE
);

-- Партнёры
CREATE TABLE Partners (
    Id INT PRIMARY KEY IDENTITY(1,1),
    PartnerTypeId INT FOREIGN KEY REFERENCES PartnerTypes(Id),
    Name NVARCHAR(100) NOT NULL,
    DirectorName NVARCHAR(100),
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    LegalAddress NVARCHAR(200),
    INN NVARCHAR(12),
    Rating INT NOT NULL DEFAULT 0 CHECK (Rating >= 0)
);

-- Типы продукции
CREATE TABLE ProductTypes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL,
    Coefficient FLOAT NOT NULL
);

-- Продукция
CREATE TABLE Products (
    Id INT PRIMARY KEY IDENTITY(1,1),
    ProductTypeId INT FOREIGN KEY REFERENCES ProductTypes(Id),
    Name NVARCHAR(150) NOT NULL,
    Articul NVARCHAR(50),
    MinPrice DECIMAL(12,2) NOT NULL
);

-- Типы материалов
CREATE TABLE MaterialTypes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL,
    DefectPercent FLOAT NOT NULL
);

-- История продаж
CREATE TABLE SalesHistory (
    Id INT PRIMARY KEY IDENTITY(1,1),
    PartnerId INT FOREIGN KEY REFERENCES Partners(Id),
    ProductId INT FOREIGN KEY REFERENCES Products(Id),
    Quantity INT NOT NULL CHECK (Quantity > 0),
    SaleDate DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE)
);

-- Вставка тестовых данных
INSERT INTO PartnerTypes (Name) VALUES ('ЗАО'), ('ООО'), ('ПАО'), ('ОАО');

INSERT INTO Partners (PartnerTypeId, Name, DirectorName, Email, Phone, LegalAddress, INN, Rating)
VALUES 
(1, 'Стройдвор', 'Андреева Ангелина Николаевна', 'angelina77@kart.ru', '492 452 22 82', 'Московская область, г. Одинцово, ул. Ленина, 21', '9432455179', 5),
(2, 'Декор и отделка', 'Саншокова Мадина Муратовна', 'mmsanshokova@lss.ru', '413 230 30 79', 'Магаданская область, г. Магадан, ул. Горького, 15', '4318170454', 7);

INSERT INTO ProductTypes (Name, Coefficient) VALUES 
('Древесно-плитные материалы', 1.5),
('Декоративные панели', 3.5),
('Плитка', 5.25),
('Фасадные материалы', 4.5),
('Напольные покрытия', 2.17);

INSERT INTO Products (ProductTypeId, Name, Articul, MinPrice) VALUES
(1, 'Фанера ФСФ 1800х1200х27 мм бежевая береза', '6549922', 5100),
(3, 'Плитка Мозаика 10x10 см цвет белый глянец', '8028248', 2500);

INSERT INTO MaterialTypes (Name, DefectPercent) VALUES
('Тип материала 1', 0.002),
('Тип материала 2', 0.005);

INSERT INTO SalesHistory (PartnerId, ProductId, Quantity, SaleDate) VALUES
(1, 1, 2000, '2025-01-10'),
(1, 2, 5000, '2025-02-15'),
(2, 2, 9500, '2025-01-20');
GO